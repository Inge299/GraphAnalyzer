--
-- PostgreSQL database dump
--

\restrict wn3MfSfUVNsopHPJlrrfBqmOSA9xgkYi2zRcfIXEKmNvt3M04C7TL1S2Gpi07dK

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artifact_relations; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.artifact_relations (
    source_id integer NOT NULL,
    target_id integer NOT NULL,
    relation_type character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.artifact_relations OWNER TO osint_user;

--
-- Name: artifact_versions; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.artifact_versions (
    id integer NOT NULL,
    artifact_id integer NOT NULL,
    version integer NOT NULL,
    data jsonb NOT NULL,
    changed_at timestamp without time zone DEFAULT now() NOT NULL,
    changed_by character varying(50)
);


ALTER TABLE public.artifact_versions OWNER TO osint_user;

--
-- Name: artifact_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.artifact_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artifact_versions_id_seq OWNER TO osint_user;

--
-- Name: artifact_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.artifact_versions_id_seq OWNED BY public.artifact_versions.id;


--
-- Name: artifacts; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.artifacts (
    id integer NOT NULL,
    project_id integer NOT NULL,
    type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    data jsonb NOT NULL,
    artifact_metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.artifacts OWNER TO osint_user;

--
-- Name: artifacts_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.artifacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artifacts_id_seq OWNER TO osint_user;

--
-- Name: artifacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.artifacts_id_seq OWNED BY public.artifacts.id;


--
-- Name: edge_types; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.edge_types (
    id integer NOT NULL,
    project_id integer NOT NULL,
    schema_id integer NOT NULL,
    name character varying(100) NOT NULL,
    source_types jsonb NOT NULL,
    target_types jsonb NOT NULL,
    attributes jsonb NOT NULL,
    color character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.edge_types OWNER TO osint_user;

--
-- Name: edge_types_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.edge_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.edge_types_id_seq OWNER TO osint_user;

--
-- Name: edge_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.edge_types_id_seq OWNED BY public.edge_types.id;


--
-- Name: edges; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.edges (
    id integer NOT NULL,
    graph_id integer NOT NULL,
    edge_id character varying(100) NOT NULL,
    source_node character varying(100) NOT NULL,
    target_node character varying(100) NOT NULL,
    type character varying(100) NOT NULL,
    attributes json NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.edges OWNER TO osint_user;

--
-- Name: edges_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.edges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.edges_id_seq OWNER TO osint_user;

--
-- Name: edges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.edges_id_seq OWNED BY public.edges.id;


--
-- Name: graphs; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.graphs (
    id integer NOT NULL,
    project_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description character varying(500),
    version integer,
    locked_by integer,
    locked_at timestamp without time zone,
    lock_expires timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.graphs OWNER TO osint_user;

--
-- Name: graphs_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.graphs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.graphs_id_seq OWNER TO osint_user;

--
-- Name: graphs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.graphs_id_seq OWNED BY public.graphs.id;


--
-- Name: node_types; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.node_types (
    id integer NOT NULL,
    project_id integer NOT NULL,
    schema_id integer NOT NULL,
    name character varying(100) NOT NULL,
    attributes jsonb NOT NULL,
    color character varying(50),
    icon character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.node_types OWNER TO osint_user;

--
-- Name: node_types_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.node_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.node_types_id_seq OWNER TO osint_user;

--
-- Name: node_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.node_types_id_seq OWNED BY public.node_types.id;


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.nodes (
    id integer NOT NULL,
    graph_id integer NOT NULL,
    node_id character varying(100) NOT NULL,
    type character varying(100) NOT NULL,
    attributes json NOT NULL,
    position_x double precision,
    position_y double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.nodes OWNER TO osint_user;

--
-- Name: nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nodes_id_seq OWNER TO osint_user;

--
-- Name: nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.nodes_id_seq OWNED BY public.nodes.id;


--
-- Name: project_schemas; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.project_schemas (
    id integer NOT NULL,
    project_id integer NOT NULL,
    schema_data jsonb NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_schemas OWNER TO osint_user;

--
-- Name: project_schemas_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.project_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_schemas_id_seq OWNER TO osint_user;

--
-- Name: project_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.project_schemas_id_seq OWNED BY public.project_schemas.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: osint_user
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.projects OWNER TO osint_user;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: osint_user
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO osint_user;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osint_user
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: artifact_versions id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_versions ALTER COLUMN id SET DEFAULT nextval('public.artifact_versions_id_seq'::regclass);


--
-- Name: artifacts id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifacts ALTER COLUMN id SET DEFAULT nextval('public.artifacts_id_seq'::regclass);


--
-- Name: edge_types id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edge_types ALTER COLUMN id SET DEFAULT nextval('public.edge_types_id_seq'::regclass);


--
-- Name: edges id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edges ALTER COLUMN id SET DEFAULT nextval('public.edges_id_seq'::regclass);


--
-- Name: graphs id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.graphs ALTER COLUMN id SET DEFAULT nextval('public.graphs_id_seq'::regclass);


--
-- Name: node_types id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.node_types ALTER COLUMN id SET DEFAULT nextval('public.node_types_id_seq'::regclass);


--
-- Name: nodes id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.nodes ALTER COLUMN id SET DEFAULT nextval('public.nodes_id_seq'::regclass);


--
-- Name: project_schemas id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.project_schemas ALTER COLUMN id SET DEFAULT nextval('public.project_schemas_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Data for Name: artifact_relations; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.artifact_relations (source_id, target_id, relation_type, created_at) FROM stdin;
\.


--
-- Data for Name: artifact_versions; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.artifact_versions (id, artifact_id, version, data, changed_at, changed_by) FROM stdin;
\.


--
-- Data for Name: artifacts; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.artifacts (id, project_id, type, name, description, data, artifact_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: edge_types; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.edge_types (id, project_id, schema_id, name, source_types, target_types, attributes, color, created_at) FROM stdin;
\.


--
-- Data for Name: edges; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.edges (id, graph_id, edge_id, source_node, target_node, type, attributes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: graphs; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.graphs (id, project_id, name, description, version, locked_by, locked_at, lock_expires, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: node_types; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.node_types (id, project_id, schema_id, name, attributes, color, icon, created_at) FROM stdin;
\.


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.nodes (id, graph_id, node_id, type, attributes, position_x, position_y, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_schemas; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.project_schemas (id, project_id, schema_data, version, created_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: osint_user
--

COPY public.projects (id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Name: artifact_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.artifact_versions_id_seq', 1, false);


--
-- Name: artifacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.artifacts_id_seq', 1, false);


--
-- Name: edge_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.edge_types_id_seq', 1, false);


--
-- Name: edges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.edges_id_seq', 1, false);


--
-- Name: graphs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.graphs_id_seq', 1, false);


--
-- Name: node_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.node_types_id_seq', 1, false);


--
-- Name: nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.nodes_id_seq', 1, false);


--
-- Name: project_schemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.project_schemas_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osint_user
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: artifact_relations artifact_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_relations
    ADD CONSTRAINT artifact_relations_pkey PRIMARY KEY (source_id, target_id, relation_type);


--
-- Name: artifact_versions artifact_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_pkey PRIMARY KEY (id);


--
-- Name: artifacts artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_pkey PRIMARY KEY (id);


--
-- Name: edge_types edge_types_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edge_types
    ADD CONSTRAINT edge_types_pkey PRIMARY KEY (id);


--
-- Name: edges edges_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edges
    ADD CONSTRAINT edges_pkey PRIMARY KEY (id);


--
-- Name: graphs graphs_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.graphs
    ADD CONSTRAINT graphs_pkey PRIMARY KEY (id);


--
-- Name: node_types node_types_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.node_types
    ADD CONSTRAINT node_types_pkey PRIMARY KEY (id);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: project_schemas project_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.project_schemas
    ADD CONSTRAINT project_schemas_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: artifact_versions uq_artifact_version; Type: CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT uq_artifact_version UNIQUE (artifact_id, version);


--
-- Name: ix_artifact_versions_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_artifact_versions_id ON public.artifact_versions USING btree (id);


--
-- Name: ix_artifacts_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_artifacts_id ON public.artifacts USING btree (id);


--
-- Name: ix_edge_types_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_edge_types_id ON public.edge_types USING btree (id);


--
-- Name: ix_edges_graph_edge; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE UNIQUE INDEX ix_edges_graph_edge ON public.edges USING btree (graph_id, edge_id);


--
-- Name: ix_edges_graph_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_edges_graph_id ON public.edges USING btree (graph_id);


--
-- Name: ix_edges_source; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_edges_source ON public.edges USING btree (graph_id, source_node);


--
-- Name: ix_edges_target; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_edges_target ON public.edges USING btree (graph_id, target_node);


--
-- Name: ix_edges_type; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_edges_type ON public.edges USING btree (type);


--
-- Name: ix_graphs_project; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_graphs_project ON public.graphs USING btree (project_id);


--
-- Name: ix_node_types_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_node_types_id ON public.node_types USING btree (id);


--
-- Name: ix_nodes_graph_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_nodes_graph_id ON public.nodes USING btree (graph_id);


--
-- Name: ix_nodes_graph_node; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE UNIQUE INDEX ix_nodes_graph_node ON public.nodes USING btree (graph_id, node_id);


--
-- Name: ix_nodes_position; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_nodes_position ON public.nodes USING btree (graph_id, position_x, position_y);


--
-- Name: ix_nodes_type; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_nodes_type ON public.nodes USING btree (type);


--
-- Name: ix_project_schemas_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_project_schemas_id ON public.project_schemas USING btree (id);


--
-- Name: ix_projects_id; Type: INDEX; Schema: public; Owner: osint_user
--

CREATE INDEX ix_projects_id ON public.projects USING btree (id);


--
-- Name: artifact_relations artifact_relations_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_relations
    ADD CONSTRAINT artifact_relations_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.artifacts(id) ON DELETE CASCADE;


--
-- Name: artifact_relations artifact_relations_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_relations
    ADD CONSTRAINT artifact_relations_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.artifacts(id) ON DELETE CASCADE;


--
-- Name: artifact_versions artifact_versions_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_artifact_id_fkey FOREIGN KEY (artifact_id) REFERENCES public.artifacts(id) ON DELETE CASCADE;


--
-- Name: artifacts artifacts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: edge_types edge_types_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edge_types
    ADD CONSTRAINT edge_types_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: edge_types edge_types_schema_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edge_types
    ADD CONSTRAINT edge_types_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES public.project_schemas(id) ON DELETE CASCADE;


--
-- Name: edges edges_graph_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.edges
    ADD CONSTRAINT edges_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES public.graphs(id) ON DELETE CASCADE;


--
-- Name: graphs graphs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.graphs
    ADD CONSTRAINT graphs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: node_types node_types_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.node_types
    ADD CONSTRAINT node_types_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: node_types node_types_schema_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.node_types
    ADD CONSTRAINT node_types_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES public.project_schemas(id) ON DELETE CASCADE;


--
-- Name: nodes nodes_graph_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES public.graphs(id) ON DELETE CASCADE;


--
-- Name: project_schemas project_schemas_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: osint_user
--

ALTER TABLE ONLY public.project_schemas
    ADD CONSTRAINT project_schemas_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict wn3MfSfUVNsopHPJlrrfBqmOSA9xgkYi2zRcfIXEKmNvt3M04C7TL1S2Gpi07dK

